import { useState, useEffect } from 'react'

function SpecificVerse() {
  const [verse, setVerse] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const REFERENCE = 'John+3:16' 

  useEffect(() => {
    const fetchSpecificVerse = async () => {
      setLoading(true)
      setError(null)
      try {
        const response = await fetch(`https://labs.bible.org/api/?passage=${REFERENCE}&type=json`)
        if (!response.ok) {
          throw new Error('Failed to fetch verse')
        }
        const data = await response.json()
        setVerse(data[0]) // API returns array with one object
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchSpecificVerse()
  }, [])

  return (
    <div className="text-center">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">John 3:16</h2>
      
      {loading && <p className="text-gray-500">Loading...</p>}
      
      {error && (
        <p className="text-red-500 mb-4">{error}</p>
      )}
      
      {verse && (
        <div className="bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">{verse.label}</h3>
          <p className="text-lg text-gray-700 italic">"{verse.text}"</p>
        </div>
      )}
    </div>
  )
}

export default SpecificVerse