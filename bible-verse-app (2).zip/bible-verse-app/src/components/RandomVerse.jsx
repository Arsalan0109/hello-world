import { useState } from 'react'

function RandomVerse() {
  const [verse, setVerse] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const fetchRandomVerse = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('https://labs.bible.org/api/?passage=random&type=json')
      if (!response.ok) {
        throw new Error('Failed to fetch verse')
      }
      const data = await response.json()
      setVerse(data[0]) // API returns array with one object
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="text-center">
      <button
        onClick={fetchRandomVerse}
        disabled={loading}
        className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold py-3 px-6 rounded-lg mb-6 transition-colors"
      >
        {loading ? 'Loading...' : 'Get Random Verse'}
      </button>
      
      {error && (
        <p className="text-red-500 mb-4">{error}</p>
      )}
      
      {verse && (
        <div className="bg-gray-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">{verse.label}</h2>
          <p className="text-lg text-gray-700 italic">"{verse.text}"</p>
        </div>
      )}
    </div>
  )
}

export default RandomVerse